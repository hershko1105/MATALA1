#include "Ship.h"
#include "utils.h"
#include <iostream>
using namespace std;
void Ship::clearShipFromScreen()
{
	for (int c = 0; c < _width; c++)
	{
		for (int r = 0; r < _height; r++)
		{
			gotoxy(_x + c, _y + r);
			cout << ' '; //TODO - use constant for this char
		}
	}
}

void Ship::drawShipToScreen()
{
	for (int c = 0; c < _width; c++)
	{
		for (int r = 0; r < _height; r++)
		{
			gotoxy(_x + c, _y + r);
			cout << _sign; //TODO - use constant for this char
		}
	}
}

