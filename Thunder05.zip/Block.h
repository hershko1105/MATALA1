#pragma once
#include <iostream>
#include "Ship.h"
#include "life.h"
#include "time.h"
//#include "Game.h"
#include <windows.h>


class Block {

private:
	int _x;//the places of the block
	int _y;//the places of the block
	int _sizeX; // size of the block
	int	_sizeY; // size of the block
	
public:
	int getX() {
		return _x;
	}
	int getY() {
		return _y;
	}
	int getSizeX() {
		return _sizeX;
	}
	int getSizeY() {
		return _sizeY;
	}
	void setX(int x) {
		_x = x;
	}
	void setY(int y) {
		_y = y;
	}
	void setSizeX(int sizeX) {
		_sizeX = sizeX;
	}
	void setSizeY(int sizeY) {
		_sizeY = sizeY;
	}
};