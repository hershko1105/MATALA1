#pragma once
void gotoxy(int x, int y);
