#pragma once
#include <windows.h>
#include <iostream>


using namespace std;
#define startTime 60
#define startMinutes 3


class Time {
private:
	int _minutesStat;
	int _secondStat;

public:
	int getMinuteStat() {
		return _minutesStat;
	}
	int getSecondStat() {
		return _secondStat;
	}
	void setMinuteStat(int newMinuteStat) {
		_minutesStat = newMinuteStat;
	}
	void setSecondStat(int newSecondStat) {
		_secondStat = newSecondStat;
	}
	void stepTime() {
		if (_secondStat > 0) {
			setSecondStat(_secondStat - 1);
		}
		else if (_minutesStat > 0) {
			setSecondStat(startTime - 1);
			setMinuteStat(_minutesStat - 1);
		}
		else {
			cout << "TIME IS OVER" << endl;
		}

	}
	void printingTime(bool keepRun) {// function that print the time left while the game keep running (the bool keepRun) and while you have time
		while (keepRun) {
			cout << _minutesStat << " : " << _secondStat << endl;
			stepTime();
			Sleep(1000);
			if (_minutesStat == 0 && _secondStat == 0) {
				keepRun = false;
			}

		}

	}
	void resetTime() {
		_minutesStat = startMinutes;
		_secondStat = startTime;
	}



};