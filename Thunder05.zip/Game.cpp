#include "Game.h"
#include "Ship.h"
#include "life.h"
#include "time.h"
#include "Block.h"
#include <windows.h>
#include <conio.h>

//TODO - use static data members
#define START_GAME 1
#define PRINT_INST 8
#define EXIT_GAME 9
#define ESC_CHAR_NUM 27

void Game::run() {
	int select;

	//todo - while user did not chose 9 - exit //ask Avi
	showEntryMenu();
	select = getUserSelect();
	while (select != START_GAME && select != PRINT_INST && select != EXIT_GAME)//check with Avi
	{
		cout << "not valid choice, please choose again" << endl;
		showEntryMenu();
		select = getUserSelect();
	}
	while (select != EXIT_GAME) {
		switch (select)
		{
		case START_GAME:
			startNewGame();
			showEntryMenu();
			select = getUserSelect();
			while (select != START_GAME && select != PRINT_INST && select != EXIT_GAME)//check with Avi
			{
				cout << "not valid choice, please choose again" << endl;
				showEntryMenu();
				select = getUserSelect();
			}
			break;
		case PRINT_INST:
			printInstructions();
			showEntryMenu();
			select = getUserSelect();
			while (select != START_GAME && select != PRINT_INST && select != EXIT_GAME)//check with Avi
			{
				cout << "not valid choice, please choose again" << endl;
				showEntryMenu();
				select = getUserSelect();
			}
			break;

			//case EXIT_GAME:
			////	exitGame();
			//	break;
		}

	}
	if (select == EXIT_GAME) {
		exitGame();
	}

}



void Game::showEntryMenu() {
	system("cls");
	cout << "please choose an option:" << endl;
	cout << "(" << START_GAME << ") Start a new game" << endl;
	cout << "(" << PRINT_INST << ") Present instructionsand keys" << endl;
	cout << "(" << EXIT_GAME << ") EXIT" << endl;
}

int Game::getUserSelect() {

	//return 1; //todo - stub. only for debug
	int select;
	cin >> select;
	return select;
}

bool Game::checkMove(char userSelect) {
	Ship* currShip;
	if (_bigShipSelected)
	{
		currShip = &_bigShip;
	}
	else
		currShip = &_smallShip;

	//TODO - add checks for hitting the other ship/a block etc

	for (int c = 0; c < currShip->getWidth(); c++)
	{
		for (int r = 0; r < currShip->getHeight(); r++)
		{
			int x = currShip->getX() + c + currShip->getDirX();
			int y = currShip->getY() + r + currShip->getDirY();
			if (_board[y][x] == WALL_CHAR)
				return false; // cannot move, at lease one point hits a wall
		}
	}
	return true;
}

void Game::startNewGame()
{
	bool gamecheck = true;
	char userSelect = DONT_MOVE;
	// init everything
	_bigShip.init(10, 5, 2, 2, STAY, BIG_SHIP_CHAR); //Ship::init( 10, 5, 2, 2, STAY, &bigShip);
	_smallShip.init(28, 9, 2, 1, MOVE, SMALL_SHIP_CHAR); //Ship::init( 28, 9, 2, 1, MOVE, &smallShip);
	_bigShipSelected = true;

	_life.reSetLife();//for restarting the life for the beginners life
	initBoard();
	_time.resetTime();
	_life.reSetLife();
	showBoard();
	// show start screen

	// game loop
	while (gamecheck) {
		//TODO no need to redraw entire board every turn - onky the changes
		//showBoard();
		if (_kbhit()) {
			userSelect = _getch();
			if (userSelect != ESC_CHAR_NUM) {//in case he didnt press ESC, to check what to do with ESC
				if (userSelect == SWITCH_TO_SMALL_SHIP_KEYU|| userSelect == SWITCH_TO_SMALL_SHIP_KEYL) {
					_bigShipSelected = false;
				}
				if (userSelect == SWITCH_TO_BIG_SHIP_KEYU || userSelect == SWITCH_TO_BIG_SHIP_KEYL) {
					_bigShipSelected = true;
				}
				if (userSelect == MOVE_LEFT_KEYL || userSelect == MOVE_LEFT_KEYU || userSelect == MOVE_UP_KEYL || userSelect == MOVE_DOWN_KEYU || userSelect == MOVE_RIGHT_KEYL || userSelect == MOVE_RIGHT_KEYU) {
					setShipDirection(userSelect);
				}
			}
			else
			{
				//TODO
				// call a function that:
				// cls
				// show in game menu
				// option = getch()
				// when the user chooses to continue - the function ends
				// cls + show entirely board 
			}
		}
		
		if (userSelect != DONT_MOVE)
		{
			bool canMove = checkMove(userSelect);
			if (canMove) {
				moveShip(userSelect);
			}
		}
		
		//updateBoard();//ask Avi if OK
		Sleep(500);


	}




}

void Game::initBoard()
{
	// Initialize the board

	//todo: complete

	for (int r = 0; r < BOARD_HEIGHT; r++) {
		for (int c = 0; c < BOARD_WIDTH; c++) {
			//todo - modify to look good
			if (r == 0 || r == BOARD_HEIGHT - 1 || c == 0 || c == BOARD_WIDTH - 1)
				_board[r][c] = WALL_CHAR;
			else
				_board[r][c] = ' ';
		}
	}

	//todo - add ships to board according to the ship x/y and width and height
	//to do define to the symbols
	_board[_bigShip.getY()][_bigShip.getX()] = BIG_SHIP_CHAR;
	_board[_bigShip.getY()][_bigShip.getX() + 1] = BIG_SHIP_CHAR;
	_board[_bigShip.getY() + 1][_bigShip.getX()] = BIG_SHIP_CHAR;
	_board[_bigShip.getY() + 1][_bigShip.getX() + 1] = BIG_SHIP_CHAR;
	//ask Avi about small ship
	_board[_smallShip.getY()][_smallShip.getX()] = SMALL_SHIP_CHAR;
	_board[_smallShip.getY()][_smallShip.getX() + 1] = SMALL_SHIP_CHAR;
	//place of Blocks - check it
	//TODO - in the future - make this an array of blocks
    // and add each one to the board
	for (int x = _block.getX(); x < _block.getSizeX() + _block.getX(); x++) {
		for (int y = _block.getY(); y < _block.getSizeY() + _block.getY(); y++) {
			_board[x][y] = BLOCK_CHAR;
		}

	}


	// Place the exit point on the board
	_board[BOARD_HEIGHT - 2][BOARD_WIDTH - 2] = EXIT_CHAR;


}


void Game::showBoard()
{
	bool checkTime = false;
	system("cls");
	//printing the place for time and life
	//for (int i = 0; i < BOARD_WIDTH; i++) {
	//	cout << "*";
	//}
	//cout << endl;
	//cout << "*";
	//for (int i = 1; i < BOARD_WIDTH - 1; i++) {
	//	cout << " ";
	//}
	//cout << "*";
	//cout << endl;
	//cout << "*";
	//for (int i = 1; i < (BOARD_WIDTH - 1) / 2 - 4; i++) {
	//	cout << " ";
	//}
	//if (_time.getMinuteStat() != 0 && _time.getSecondStat() != 0) {
	//	checkTime = true;
	//}
	////_time.printingTime(checkTime);
	//for (int i = 1; i < BOARD_WIDTH - 1 - ((BOARD_WIDTH - 1) / 2 + 3); i++) {
	//	cout << " ";
	//}
	//cout << "*";
	//cout << endl;

	//cout << "*";
	//for (int i = 1; i < (BOARD_WIDTH - 1) / 2 - 4; i++) {
	//	cout << " ";
	//}
	////printingCurrLife();//added after the life functions
	//for (int i = 1; i < (BOARD_WIDTH - 1) / 2 + 11; i++) {
	//	cout << " ";
	//}
	//cout << "*";
	//cout << endl;

	//for (int i = 0; i < BOARD_WIDTH; i++) {
	//	cout << "*";
	//}
	//cout << endl;

	//cout << endl << endl;
	for (int r = 0; r < BOARD_HEIGHT; r++) {
		for (int c = 0; c < BOARD_WIDTH; c++) {
			cout << _board[r][c];
		}
		cout << endl;
	}
	cout << endl;

}

//function for showing life
void Game::printingCurrLife() {
	int currLife = _life.getCurrLife();
	cout << "you have " << currLife << " left" << endl;
}

void Game::printInstructions()
{
	//todo
	cout << "The keys to the game are :" << endl;
	cout << "Left - a / A" << endl;
	cout << "Right - d / D" << endl;
	cout << "Up - w / W" << endl;
	cout << "Down - x / X" << endl;
	cout << "switch to the big ship - B / b" << endl;
	cout << "switch to the big ship - S / s" << endl;
}

void Game::exitGame()
{
	system("cls");
	cout << "Thank you for playing" << endl;
	exit(0);
}


char Game::retBoardInfo(int xPlace, int yPlace) {
	return _board[xPlace][yPlace];
}

void Game::printTime() {

}
/*
	Ship _bigShip;
	Ship _smallShip;
	life _life;
	char _board[BOARD_HEIGHT][BOARD_WIDTH];
	Time _time;

*/

void Game::setShipDirection(char direction)
{
	Ship& currShip = _bigShipSelected ? _bigShip : _smallShip;

	switch (direction) {
	case MOVE_LEFT_KEYU:
		currShip.setDirX(-1);
		currShip.setDirY(0);
		break;
	case MOVE_RIGHT_KEYU:
		currShip.setDirX(1);
		currShip.setDirY(0);
		break;
	case MOVE_DOWN_KEYU:
		currShip.setDirX(0);
		currShip.setDirY(1);
		break;
	case MOVE_UP_KEYU:
		currShip.setDirX(0);
		currShip.setDirY(-1);
		break;
	case MOVE_LEFT_KEYL:
		currShip.setDirX(-1);
		currShip.setDirY(0);
		break;
	case MOVE_RIGHT_KEYL:
		currShip.setDirX(1);
		currShip.setDirY(0);
		break;
	case MOVE_DOWN_KEYL:
		currShip.setDirX(0);
		currShip.setDirY(1);
		break;
	case MOVE_UP_KEYL:
		currShip.setDirX(0);
		currShip.setDirY(-1);
		break;
	}
}
void Game::moveShip(char direction) {
	Ship& currShip = _bigShipSelected ? _bigShip : _smallShip;
	
	currShip.clearShipFromScreen();
	currShip.moveInCurrDir();
	//TODO - postpone the block moves to much much later, as this is a complication :)
	// Move the ship and the block
	//if (board[shipY + dirY][shipX + dirX] != WALL_CHAR) 
	//{
	//	if (board[shipY + dirY][shipX + dirX] == BLOCK_CHAR) 
	//	{
	//		if (board[shipY + 2 * dirY][shipX + 2 * dirX] != WALL_CHAR) 
	//		{
	//			board[shipY + 2 * dirY][shipX + 2 * dirX] = BLOCK_CHAR;
	//		}
	//	}

	//	shipX += dirX;
	//	shipY += dirY;
	//}
	currShip.drawShipToScreen();


}

void Game::switchShip() {
	_bigShipSelected = !_bigShipSelected;
}

void Game::updateBoard() {
	//TODO - ask Daniel why do we need this function

}

bool Game::checkIfBlockFall() {
	int i;
	int check = 0;
	for (i = _block.getX(); i < _block.getX() + _block.getSizeX(); i++) {
		if (retBoardInfo(i, _block.getY() - 1) != ' ') {
			check++;
		}
	}
	if (check == 0) {
		return true;
	}
	else {
		return false;
	}
}

