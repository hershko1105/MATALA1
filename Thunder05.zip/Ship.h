#pragma once
//TODO - static
#define STAY 1
#define MOVE 0
class Ship
{
private:
	int _x;
	int _y;
	int _dirX;
	int _dirY;
	int _width;
	int _height;
	int _motion; //STAY - 1 MOVE - 0
	char _sign;
public:
	void moveInCurrDir() { //TODO move to .cpp file
		_x += _dirX;
		_y += _dirY;
	}
	void clearShipFromScreen();
	void drawShipToScreen();
	//TODO - move code to .cpp file
	void init(int x, int y, int width, int height, int motion, char sign/*,Ship* this*/) {
		_x = x;
		_y = y;
		_width = width;
		_height = height;
		_motion = motion;
		_sign = sign;
		_dirX = _dirY = 0;
	}
	//todo - more getters and setters - wherever needed - DONE
	int getX() {
		return _x;
	}
	int getY() {
		return _y;
	}

	int getDirX() {
		return _dirX;
	}
	int getDirY() {
		return _dirY;
	}
	int getWidth() {
		return _width;
	}
	int getHeight() {
		return _height;
	}
	int getMotion() {
		return _motion;
	}
	void setX(int x) {
		_x = x;
	}
	void setY(int y) {
		_y = y;
	}
	void setDirX(int dirX) {
		_dirX = dirX;
	}
	void setDirY(int dirY) {
		_dirY = dirY;
	}
	void setWidth(int width) {
		_width = width;
	}
	void setHeight(int height) {
		_height = height;
	}
	void setMotion(int motion) {
		_motion = motion;
	}

};

