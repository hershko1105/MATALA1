#pragma once
#include <iostream>
#include "Ship.h"
#include "life.h"
#include "time.h"
#include "Block.h"


using namespace std;

class Game
{
public:
	// Define the size of the board
	static const int BOARD_WIDTH = 80;
	static const int BOARD_HEIGHT = 25;

	static const int SLEEP_DURATION = 500;
	// Define the characters for the ships, blocks, walls, and exit point
	static const char BIG_SHIP_CHAR = '#';
	static const char SMALL_SHIP_CHAR = '@';
	static const char BLOCK_CHAR = '*';
	static const char WALL_CHAR = 'W';
	static const char EXIT_CHAR = 'E';
	

	// Define the keys for ship movement
	static const char MOVE_LEFT_KEYL = 'a';
	static const char MOVE_RIGHT_KEYL = 'd';
	static const char MOVE_DOWN_KEYL = 'x';
	static const char MOVE_UP_KEYL = 'w';
	static const char MOVE_LEFT_KEYU = 'A';
	static const char MOVE_RIGHT_KEYU = 'D';
	static const char MOVE_DOWN_KEYU = 'X';
	static const char MOVE_UP_KEYU = 'W';
	static const char DONT_MOVE = 'o'; // dummy to avoid move before user hit the first key
	static const char SWITCH_TO_SMALL_SHIP_KEYL = 's';
	static const char SWITCH_TO_SMALL_SHIP_KEYU = 'S';
	static const char SWITCH_TO_BIG_SHIP_KEYL = 'b';
	static const char SWITCH_TO_BIG_SHIP_KEYU = 'B';

private:
	Ship _bigShip;
	Ship _smallShip;
	life _life;
	char _board[BOARD_HEIGHT][BOARD_WIDTH];
	Time _time;
	Block _block;
	bool _bigShipSelected;
	void showEntryMenu(/*,Game* this*/);
	int getUserSelect(/*,Game* this*/);
	void startNewGame(/*,Game* this*/);
	void printInstructions(/*,Game* this*/);
	void exitGame(/*,Game* this*/);
	void initBoard(/*,Game* this*/);
	void showBoard(/*,Game* this*/);
	void menu(/*,Game* this*/);
	//for showing life

	void moveShip(char direction);
	void switchShip();
	void updateBoard();
	bool checkMove(char userSelect);
	void setShipDirection(char direction);



public:
	void run(/*,Game* this*/);
	void printingCurrLife();
	bool checkIfBlockFall();
	char retBoardInfo(int xPlace, int yPlace);
	void printTime();
	bool isBlockFall();

	void Printinstructions()
	{
		cout << "The keys to the game are" << endl;
		cout << "Left - a / A" << endl;
		cout << "Right - d / D" << endl;
		//todo - complete
		cout << "Up - w / W" << endl;
		cout << "Down - x / X" << endl;
		cout << "switch to the big ship - B / b" << endl;
		cout << "switch to the big ship - S / s" << endl;
	}


	//void StartNewGame(){
	//	//while (!EndGame)
	//	//	char Action;
	//	//action = char.parse(console.readline());
	//	//switch action :
	//	//case �Esc�: Escape(arr[][] BoardGame, ? );
	//	//case �a� / �A�:  MoveRigh(arr[][] BoardGame,

	//}



	//void menu{
	//	//int select;
	//cout << "(1) Start a new game" << endl;
	//cout << "(8) Present instructions and keys" << endl;
	//cout << "(9) EXIT" << endl;
	////console.writeline(�(1) Start a new game / n(8) Present instructions and keys / n(9) EXIT�
	////select = int.parse(console.readline());

	////switch select :
	////case 1: StartNewGame();
	////case 8: Printinstructions();
	////case 9: exit(); //������ �� ������ �exit() ����� �����
	//}



	//void Escape(arr[][] BoardGame, ? ) {
	//char decision;
	//cout << �Game paused, press ESC again to continue or 9 to Exit�;
	//cin << decision;
	//if (decision == �9�) {
	//	exit(); //������ �� ������ �exit() ����� �����
	//}//if
	//else if (decision == esc) {
	//backToGame(arr[][] BoardGame, ? );
	//}//else if

	//}//Escape




	//arr[][] createNewBoard() {
	//	arr[ROW_SIZE][COLUMN_SIZE] outputBoard = {�0�};// ����� �� ������� ��� �����
	//	return outputBoard;
	//}//createNewBoard



};

