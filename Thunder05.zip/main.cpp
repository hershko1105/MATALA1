#include <iostream>
#include "Game.h"

using namespace std;
//struct Block {
//	int x, y;  // we decide when we create block where he will be
//	int sizeX, sizeY;  // size of the block
//	char symbol;  // character to represent the block 
//};//check with Daniel


int main() {
	Game game; // game class is the "Thunderbirds App"
	game.run(); // all the game logid starts from here

	return 0;

}

